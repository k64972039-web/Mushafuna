# مصحفنا — Android

مشروع تطبيق أندرويد أصلي باستخدام Kotlin وJetpack Compose، وليس موقعاً أو WebView.

## الوظائف الموجودة في النسخة الأولية
- فهرس السور من Quran.com API.
- عرض نص الآيات بالرسم العثماني من Quran.com API.
- تشغيل تلاوة السورة عبر مشغل Android Media3.
- البحث عن السور.
- حفظ آخر سورة والمفضلة محلياً.

## ملاحظات مهمة قبل النشر
- هذه نسخة أولية (MVP) وليست إصداراً نهائياً موثقاً للنشر.
- الاتصال مطلوب لجلب الفهرس والآيات وتشغيل الصوت. التخزين المؤقت الكامل والتنزيل الصوتي للاستخدام دون اتصال يحتاجان إلى استكمال واختبار.
- يجب مراجعة مصدر الصوت وحقوق إعادة التوزيع، والتحقق من دقة النص والرسم والتشكيل على أجهزة فعلية قبل النشر.
- واجهة التطبيق لا تدّعي أنها مصحف معتمد للطباعة أو التلاوة الرسمية قبل المراجعة الشرعية والفنية.

## البناء
افتح المجلد في Android Studio (نسخة تدعم Android Gradle Plugin 8.7.3)، ثم انتظر مزامنة Gradle.
من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
ملف APK التجريبي يظهر عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## API
- Quran text and chapter metadata: https://api.quran.com/api/v4/
- Audio stream: verses.quran.com (recitation endpoint configured in MainActivity)
