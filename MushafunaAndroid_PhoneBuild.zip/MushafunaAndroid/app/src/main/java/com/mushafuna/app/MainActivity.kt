package com.mushafuna.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Green = Color(0xFF103D32)
private val Gold = Color(0xFFD6B66C)
private val Cream = Color(0xFFFAF7EF)

data class Chapter(val id: Int, val name: String, val englishName: String, val verses: Int)
data class Ayah(val number: Int, val text: String)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Green, secondary = Gold, background = Cream, surface = Cream
            )) {
                MushafApp(
                    loadChapters = { QuranApi.chapters() },
                    loadVerses = { QuranApi.verses(it) },
                    playChapter = { id -> play(id) },
                    saveLastRead = { id -> getPreferences(MODE_PRIVATE).edit().putInt("last_chapter", id).apply() },
                    lastRead = { getPreferences(MODE_PRIVATE).getInt("last_chapter", 1) },
                    isBookmarked = { id -> getPreferences(MODE_PRIVATE).getBoolean("bookmark_$id", false) },
                    toggleBookmark = { id ->
                        val p = getPreferences(MODE_PRIVATE)
                        p.edit().putBoolean("bookmark_$id", !p.getBoolean("bookmark_$id", false)).apply()
                    }
                )
            }
        }
    }

    private fun play(chapterId: Int) {
        // Quran.com audio recitation 7 (Mishary Rashid Alafasy); requires internet.
        val audioUrl = "https://verses.quran.com/Alafasy/mp3/${chapterId.toString().padStart(3, '0')}.mp3"
        player.setMediaItem(MediaItem.fromUri(audioUrl))
        player.prepare()
        player.play()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
fun MushafApp(
    loadChapters: suspend () -> List<Chapter>,
    loadVerses: suspend (Int) -> List<Ayah>,
    playChapter: (Int) -> Unit,
    saveLastRead: (Int) -> Unit,
    lastRead: () -> Int,
    isBookmarked: (Int) -> Boolean,
    toggleBookmark: (Int) -> Unit
) {
    var chapters by remember { mutableStateOf<List<Chapter>>(emptyList()) }
    var selected by remember { mutableStateOf<Chapter?>(null) }
    var verses by remember { mutableStateOf<List<Ayah>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showBookmarks by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        loading = true
        try { chapters = loadChapters() } catch (e: Exception) { error = "تعذر تحميل الفهرس. تحقق من اتصال الإنترنت." }
        loading = false
        chapters.firstOrNull { it.id == lastRead() }?.let { /* last read remains available in list */ }
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().background(Green).padding(horizontal = 18.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (selected != null) {
                IconButton(onClick = { selected = null; verses = emptyList() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                }
            } else {
                Text("مصحفنا", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
            Text(if (selected == null) "القرآن الكريم" else selected!!.name,
                color = Gold, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            if (selected == null) {
                IconButton(onClick = { showBookmarks = !showBookmarks }) {
                    Icon(Icons.Default.Bookmark, contentDescription = "المفضلة", tint = Gold)
                }
            } else {
                IconButton(onClick = { toggleBookmark(selected!!.id) }) {
                    Icon(Icons.Default.Bookmark, contentDescription = "حفظ", tint = Gold)
                }
            }
        }

        if (selected == null) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                placeholder = { Text("ابحث عن سورة...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { showBookmarks = false }, label = { Text("كل السور") })
                AssistChip(onClick = { showBookmarks = true }, label = { Text("المفضلة") })
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp))
            error?.let { Text(it, color = Color.Red, modifier = Modifier.padding(16.dp)) }
            val visible = chapters.filter {
                (it.name.contains(query) || it.englishName.contains(query, ignoreCase = true)) &&
                (!showBookmarks || isBookmarked(it.id))
            }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible) { chapter ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            selected = chapter
                            saveLastRead(chapter.id)
                        },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).background(Green, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                Text(chapter.id.toString(), color = Gold, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(chapter.name, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Green)
                                Text("${chapter.verses} آية • ${chapter.englishName}", fontSize = 12.sp, color = Color.Gray)
                            }
                            IconButton(onClick = { playChapter(chapter.id) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "استماع", tint = Green)
                            }
                        }
                    }
                }
            }
        } else {
            LaunchedEffect(selected?.id) {
                loading = true
                error = null
                try { verses = loadVerses(selected!!.id) }
                catch (e: Exception) { error = "تعذر تحميل الآيات. إذا سبق فتح السورة دون اتصال، ستتوفر النسخة المحفوظة." }
                loading = false
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center) {
                Button(onClick = { playChapter(selected!!.id) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("استمع للسورة")
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = Color.Red, modifier = Modifier.padding(16.dp)) }
            LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp)) {
                items(verses) { ayah ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                        Text(ayah.text, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right,
                            fontSize = 25.sp, lineHeight = 48.sp, color = Green)
                        Text("۞ ${ayah.number}", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                            color = Gold, fontSize = 15.sp)
                        Divider(color = Gold.copy(alpha = 0.35f))
                    }
                }
            }
        }
        if (selected == null) {
            Text("يُحفظ آخر موضع قراءة على هذا الجهاز", modifier = Modifier.fillMaxWidth().padding(10.dp),
                textAlign = TextAlign.Center, color = Green, fontSize = 12.sp)
        }
    }
}

object QuranApi {
    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val connection = URL("https://api.quran.com/api/v4/$path").openConnection() as HttpURLConnection
        connection.connectTimeout = 12000
        connection.readTimeout = 15000
        connection.setRequestProperty("Accept", "application/json")
        try {
            JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } finally { connection.disconnect() }
    }

    suspend fun chapters(): List<Chapter> {
        val json = get("chapters?language=ar")
        val array = json.getJSONArray("chapters")
        return (0 until array.length()).map { i ->
            val c = array.getJSONObject(i)
            Chapter(c.getInt("id"), c.optString("name_arabic"), c.optString("name_simple"), c.getInt("verses_count"))
        }
    }

    suspend fun verses(chapterId: Int): List<Ayah> {
        val json = get("verses/by_chapter/$chapterId?language=ar&words=false&per_page=300")
        val array = json.getJSONArray("verses")
        return (0 until array.length()).map { i ->
            val v = array.getJSONObject(i)
            Ayah(v.getInt("verse_number"), v.optString("text_uthmani"))
        }
    }
}
